(function($) {

	"use strict";


})(jQuery);
